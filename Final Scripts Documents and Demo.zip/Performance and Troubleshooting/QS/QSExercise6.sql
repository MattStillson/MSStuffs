Use QueryStoreDemo
SELECT qt.query_sql_text, q.query_id, qt.query_text_id, 
p1.plan_id AS plan1, rsi1.start_time AS runtime_stats_interval_1, rs1.runtime_stats_id AS runtime_stats_id_1, rs1.avg_duration AS avg_duration_1, 
p2.plan_id AS plan2, rsi2.start_time AS runtime_stats_interval_2, rs2.runtime_stats_id AS runtime_stats_id_2, rs2.avg_duration AS plan2
FROM	sys.query_store_query_text qt 
JOIN 	sys.query_store_query q ON qt.query_text_id = q.query_text_id 
JOIN	sys.query_store_plan p1 ON q.query_id = p1.query_id 
JOIN	sys.query_store_runtime_stats rs1 ON p1.plan_id = rs1.plan_id 
JOIN	sys.query_store_runtime_stats_interval rsi1 ON rsi1.runtime_stats_interval_id = rs1.runtime_stats_interval_id 
JOIN	sys.query_store_plan p2 ON q.query_id = p2.query_id 
JOIN	sys.query_store_runtime_stats rs2 ON p2.plan_id = rs2.plan_id 
JOIN	sys.query_store_runtime_stats_interval rsi2 ON rsi2.runtime_stats_interval_id = rs2.runtime_stats_interval_id
WHERE	rsi1.start_time > dateadd(hour, -48, getutcdate()) AND	rsi2.start_time > rsi1.start_time AND
	rs2.avg_duration > 2*rs1.avg_duration
