/*
***************************************************************************************
Step 1:Memory-Optimized Tables with ColumnStore
***************************************************************************************
*/
-- Set your current database, run these 2 lines
Use AdventureWorks2016
Go
/*
*************************************************************************************
Step 2:CREATE Memory Optimized TABLE
*************************************************************************************
*/
CREATE TABLE Account_memorytoptimized (  
    accountkey int NOT NULL ,  
    Accountdescription nvarchar (50),  
    accounttype nvarchar(50),  
    unitsold int,  
    CONSTRAINT[pk_account_hk] PRIMARY KEY NONCLUSTERED HASH(accountkey) with (BUCKET_COUNT=10000000))  
    WITH (MEMORY_OPTIMIZED = ON,DURABILITY=SCHEMA_AND_DATA );  
GO  

/*
**************************************************************************************
Step 3: Add clustered colummnstore index 
**************************************************************************************
*/

Alter table Account_memorytoptimized add index tk_account_cci clustered columnstore

/*
***************************************************************************************
Step 4: Look at the index definition
***************************************************************************************
*/

Select  name, index_id, type_desc, compression_delay from sys.indexes where object_id=object_id('Account_memorytoptimized')

Set nocount on
Go

/*
******************************************************************************************
Step 5: Insert  5 millions rows into the memory optimized table
*******************************************************************************************
*/
-- insert into the main table load 5 million rows
declare @outerloop int = 0
declare @i int = 0
while (@outerloop < 5000000)
begin
Select @i = 0
begin tran
while (@i < 2000)
begin
insert Account_memorytoptimized values (@i+@outerloop, 'test1', 'test2',@i) 
set @i += 1;
end
commit
set @outerloop = @outerloop + @i
set @i = 0
end
go

/*
**************************************************************************************************
Step 6: Select query: verify that we have inserted these 5 millions row
**************************************************************************************************
*/
Select count(*) from Account_memorytoptimized

/*



***************************************************************************************************
Step 7:Simple query with columnstore index
***************************************************************************************************
*/


SET STATISTICS TIME ON
Select avg(convert(bigint, unitsold)) from Account_memorytoptimized

/*
***********************************************************************************************************
Step 8: Same query but this time without the columnstore index
***********************************************************************************************************
*/

Select avg(convert(bigint, unitsold)) from Account_memorytoptimized with (index= pk_account_hk)

/*
***************************************************************************************************

