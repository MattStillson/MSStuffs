/*
***************************************************************************************************
Step 1: Non-Clustered Columnstore Indexes
***************************************************************************************************
*/
-- Set your current database, run these 2 lines
Use AdventureWorks2016
Go

/*
**************************************************************************************************
Step 2: Create Table
**************************************************************************************************
*/

--Creating the table with required column for analytics
Create table orders (
AccountKey int not null,
customername nvarchar (50),
OrderNumber bigint,
PurchasePrice decimal (9,2),
OrderStatus smallint not NULL,
OrderStatusDesc nvarchar (50)) 

/*
***************************************************************************************************
Step 3: Create Clustered Indexes
***************************************************************************************************
*/

--Create a clustered index on �OrderStatus�
Create clustered index orders_ci on orders(OrderStatus)

/*
***************************************************************************************************
Step 4: LoadData
***************************************************************************************************
*/

-- insert into the main table load 1.5 million rows
declare @outerloop int = 0
declare @i int = 0
declare @purchaseprice decimal (9,2)
declare @customername nvarchar (50)
declare @accountkey int
declare @orderstatus smallint
declare @orderstatusdesc nvarchar(50)
declare @ordernumber bigint
while (@outerloop < 1500000)
begin
Select @i = 0
begin tran
while (@i < 2000)
begin
set @ordernumber = @outerloop + @i
set @purchaseprice = rand() * 1000.0
set @accountkey = convert (int, RAND ()*1000)
set @orderstatus = convert (smallint, RAND()*100)
if (@orderstatus >= 5) set @orderstatus = 5

set @orderstatusdesc  =
case @orderstatus
WHEN 0 THEN  'Order Started'
WHEN 1 THEN  'Order Closed'
WHEN 2 THEN  'Order Paid'
WHEN 3 THEN 'Order Fullfillment'
WHEN 4 THEN  'Order Shipped'
WHEN 5 THEN 'Order Received'
END
insert orders values (@accountkey,
(convert(varchar(6), @accountkey) + 'firstname'),@ordernumber, @purchaseprice,@orderstatus, @orderstatusdesc)

set @i += 1;
end
commit

set @outerloop = @outerloop + 2000
set @i = 0
end
go

/*
****************************************************************************************************
Step 5: Create NCCI Index
****************************************************************************************************
*/

--create NCCI Index
CREATE NONCLUSTERED COLUMNSTORE INDEX orders_ncci ON orders  (accountkey, customername, purchaseprice, orderstatus, orderstatusdesc)

/*
**********************************************************************************************************
Step 6: Additional Rows
***********************************************************************************************************
*/


--insert additional 200k rows
declare @outerloop int = 3000000
declare @i int = 0
declare @purchaseprice decimal (9,2)
declare @customername nvarchar (50)
declare @accountkey int
declare @orderstatus smallint
declare @orderstatusdesc nvarchar(50)
declare @ordernumber bigint
while (@outerloop < 3200000)
begin
Select @i = 0
begin tran
while (@i < 2000)
begin
set @ordernumber = @outerloop + @i
set @purchaseprice = rand() * 1000.0
set @accountkey = convert (int, RAND ()*1000)
set @orderstatus = convert (smallint, RAND()*5)
set @orderstatusdesc =
case @orderstatus
WHEN 0 THEN 'Order Started'
WHEN 1 THEN 'Order Closed'
WHEN 2 THEN 'Order Paid'
WHEN 3 THEN 'Order Fullfillment'
WHEN 4 THEN 'Order Shipped'
WHEN 5 THEN 'Order Received'
END
insert orders values (@accountkey,(convert(varchar(6), @accountkey) + 'firstname'),
@ordernumber, @purchaseprice, @orderstatus, @orderstatusdesc)
set @i += 1;
end
commit
set @outerloop = @outerloop + 2000
set @i = 0
end
go


/*
***********************************************************************************************************
Step 7: Rowgroup
***********************************************************************************************************
*/
-- look at the row group
Select object_name(object_id), index_id, row_group_id, delta_store_hobt_id, state_desc, total_rows, trim_reason_desc, transition_to_compressed_state_desc 
from sys.dm_db_column_store_row_group_physical_stats 
where object_id=object_id('orders')	

/*
*************************************************************************************************************
Step 8: NCCI Index
*************************************************************************************************************
*/

-- run the query using NCCI
DBCC DROPCLEANBUFFERS
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
select max (PurchasePrice) from orders


/*
***************************************************************************************************************
Step 9: without using NCCI
***************************************************************************************************************
*/
-- run the query without using NCCI
DBCC DROPCLEANBUFFERS
Go
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
select max (PurchasePrice) from orders 
option (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX)

/*
********************************************************************************************************
Step 10: complex query using NCCI
********************************************************************************************************
*/

-- a more complex query using NCCI
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
select top 5 customername, sum (PurchasePrice), Avg (PurchasePrice)
from orders
where purchaseprice > 90.0 and OrderStatus=5
group by customername

/*
***********************************************************************************************************
Step 11: more complex query without NCCI
***********************************************************************************************************
*/

--a more complex query without NCCI
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
select top 5 customername, sum (PurchasePrice), Avg (PurchasePrice)
from orders
where purchaseprice > 90.0 and OrderStatus = 5
group by customername
option (IGNORE_NONCLUSTERED_COLUMNSTORE_INDEX)

/*
***********************************************************************************************************
step 12: Drop existing NCCI 
***********************************************************************************************************
*/

--Drop existing NCCI Index
DROP Index orders_ncci on Orders

/*
***********************************************************************************************************
step 13:columnstore index with a filtered condition  
***********************************************************************************************************
*/

--Create the columnstore index with a filtered condition  
CREATE NONCLUSTERED COLUMNSTORE INDEX orders_ncci ON orders  (accountkey, customername, purchaseprice, orderstatus)  
where orderstatus = 5  

/*
**************************************************************************************************************
step 14:rows both from newly created NCCI index and from 'hot' rows 
**************************************************************************************************************
*/

SELECT top 5 customername, sum (PurchasePrice)  
FROM orders  
WHERE purchaseprice > 100.0   
Group By customername  


/*

*************************************************************************************************************
step 15: create a sample table and then creating nonclustered columnstore index 
*************************************************************************************************************
*/

-- Create a sample table  
create table t_compressdelay (  
               accountkey                      int not null,  
               accountdescription              nvarchar (50) not null,  
               accounttype                     nvarchar(50),  
               accountCodeAlternatekey         int)  
  
-- after it has been marked closed  
CREATE NONCLUSTERED COLUMNSTORE index t_colstor_cci on t_compressdelay (accountkey, accountdescription, accounttype)   
                       WITH (DATA_COMPRESSION= COLUMNSTORE, COMPRESSION_DELAY = 100);  



