USE master;
ALTER DATABASE AdventureWorksDW2016
SET RECOVERY FULL;
BACKUP DATABASE AdventureWorksDW2016
   TO URL = 'https://<<storagename>>.blob.core.windows.net/<<containername>>/AdventureWorksDW2016_onprem.bak' 
