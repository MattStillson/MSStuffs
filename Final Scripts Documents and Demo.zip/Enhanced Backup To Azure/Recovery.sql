-- restore and recover to a point in time between the times of two transaction log backups, and then verify the row count
ALTER DATABASE AdventureworksDW2016 SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
RESTORE DATABASE AdventureworksDW2016 
   FROM URL = 'https://<mystorageaccountname>.blob.core.windows.net/<mystorageaccountcontainername>/<firstbackupfile>.bak' 
   WITH NORECOVERY,REPLACE;
RESTORE LOG AdventureworksDW2016 
   FROM URL = 'https://<mystorageaccountname>.blob.core.windows.net/<mystorageaccountcontainername>/<secondbackupfile>.bak'  
   WITH RECOVERY, STOPAT = 'June 26, 2015 01:48 PM';
ALTER DATABASE AdventureworksDW2016 set multi_user;
-- get new count
SELECT COUNT (*) FROM AdventureworksDW2016.Production.Location ;
