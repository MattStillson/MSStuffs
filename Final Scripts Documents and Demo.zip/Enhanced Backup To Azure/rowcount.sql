-- Verify row count at start
SELECT COUNT (*) from AdventureworksDW2016.Production.Location;
