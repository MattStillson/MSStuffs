-- Restore AdventureWorksDW2016 from URL to SQL Server instance using Azure blob storage for database files
RESTORE DATABASE AdventureworksDW2016
   FROM URL = 'https://<mystorageaccountname>.blob.core.windows.net/<mystorageaccountcontainername>/AdventureWorksDW2016_onprem.bak' 
   WITH
      MOVE 'AdventureWorksDW2014_Data' to 'https://<mystorageaccountname>.blob.core.windows.net/<mystorageaccountcontainername>/AdventureworksDW2016_Data.mdf'
     ,MOVE 'AdventureWorksDW2014_Log' to 'https://<mystorageaccountname>.blob.core.windows.net/<mystorageaccountcontainername>/AdventureworksDW2016_Log.ldf'
, REPLACE
