-- Backup the AdventureworksDW2016 database with FILE_SNAPSHOT
BACKUP DATABASE AdventureworksDW2016
   TO URL = 'https://<<storagename>>.blob.core.windows.net/<<containername>>/AdventureworksDW2016_Azure.bak' 
   WITH FILE_SNAPSHOT;
