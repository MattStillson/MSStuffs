-- Create a database scoped credential  for Kerberos-secured Hadoop clusters.  
-- IDENTITY: the Kerberos user name.  
-- SECRET: the Kerberos password  
  Use TestPolybase
CREATE DATABASE SCOPED CREDENTIAL HadoopUser1   
WITH IDENTITY = 'Polybasetest', Secret = <<azure storage key>>;  
  