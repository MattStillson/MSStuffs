----------------------------------------------------------------
-- AdventureWorks samples: Row-Level Security
----------------------------------------------------------------

-- This demo uses the Sales.CustomerPII table in the AdventureWorks2016CTP3 sample database
-- to demonstrate how Row-Level Security (RLS) can be used to limit access to rows based on 
-- the identity, roles, or execution context of the user executing a query.
--
-- First, we'll show the effects of RLS by impersonating various users and seeing what they
-- can access. Then we'll show how RLS was set up to enable this behavior.
USE AdventureWorks
go

----------------------------------------------------------------
-- PART 1: What RLS looks like
----------------------------------------------------------------
-- RLS is already enabled in the sample database to limit access to sensitive data about 
-- AdventureWorks customers, contained in the Sales.CustomerPII table. The access logic is:
--   - Sales Persons should only be able to view customers who are in their assigned territory.
--   - Managers and VPs in the Sales org should be able to see all customers.

-- EXAMPLE 1:
-- The user 'michael9' is a member of the SalesPersons role, so he can only access customers 
-- who are in his assigned territory (Territory 2):
EXECUTE AS USER = 'michael9'
go

-- Only customers for Territory 2 are visible (other territories are filtered)
SELECT * FROM Sales.CustomerPII 
go

-- Cannot update or delete customers who are not in Territory 2 (other territories are filtered)
DELETE FROM Sales.CustomerPII WHERE TerritoryID = 10 -- 0 rows affected
UPDATE Sales.CustomerPII SET FirstName = 'Changed' WHERE TerritoryID = 9 -- 0 rows affected
go

-- Blocked from inserting a new customer in a territory not assigned to him...
INSERT INTO Sales.CustomerPII (CustomerID, FirstName, LastName, TerritoryID)
VALUES (0, 'Bad', 'Customer', 10) -- operation failed, block predicate conflicts

-- ...but can insert a new customer in a territory assigned to him
INSERT INTO Sales.CustomerPII (CustomerID, FirstName, LastName, TerritoryID)
VALUES (0, 'Good', 'Customer', 2) -- 1 row affected

-- Blocked from updating the territory of an accessible customer to be in an unassigned territory
UPDATE Sales.CustomerPII SET TerritoryID = 7 WHERE CustomerID = 0 -- operation failed, block predicate conflicts

-- Reset the changes
DELETE FROM Sales.CustomerPII WHERE CustomerID = 0
go

REVERT
go





