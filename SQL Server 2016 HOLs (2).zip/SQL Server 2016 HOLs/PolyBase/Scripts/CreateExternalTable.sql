USE [TestPolybase]
CREATE EXTERNAL TABLE [dbo].[Carsensordata]
([Vin] VARCHAR(255) NULL,
[model] VARCHAR(255) NULL,
[timestm] VARCHAR(255) NULL,
[outsidetemperature] [int] NULL,
[enginetemperature] [int] NULL,
[speed] [int] NULL,
[fuel] [int] NULL,
[engineoil] [int] NULL,
[tirepressure] [int] NULL,
[odometer] [int] NULL,
[city] VARCHAR(255) NULL,
[accelerator_pedal_position] [int] NULL,
[parking_brake_status] [int] NULL,
[headlamp_status] [int] NULL,
[brake_pedal_status] [int] NULL,
[tramsision] VARCHAR(255) NULL,
[ignition_status] [int] NULL,
[windshield_wiper_status] [int] NULL,
[ab] [int] NULL,
[gendate] VARCHAR(255) NULL
)
WITH (LOCATION = N'/testfolder', 
DATA_SOURCE = PolyBaseTest, 
FILE_FORMAT = PolybaseFormat, 
REJECT_TYPE = Value,  
REJECT_VALUE = 10)
GO