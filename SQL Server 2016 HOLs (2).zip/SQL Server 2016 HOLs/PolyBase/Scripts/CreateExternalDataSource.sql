CREATE EXTERNAL DATA SOURCE PolyBaseTest  
WITH  
(   
TYPE = HADOOP,   
-- wasbs:// containername@storagename.blob.core.windows.net/   
LOCATION = 'wasbs://containername@storagename.blob.core.windows.net/' 
CREDENTIAL = HadoopUser1  
);