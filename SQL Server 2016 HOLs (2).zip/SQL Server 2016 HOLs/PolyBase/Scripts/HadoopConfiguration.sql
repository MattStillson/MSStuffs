sp_configure 'hadoop connectivity', 7;
Go
reconfigure;
Go
