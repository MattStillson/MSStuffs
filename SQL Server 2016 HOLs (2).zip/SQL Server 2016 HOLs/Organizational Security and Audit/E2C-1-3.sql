USE AdventureWorks
GO
SELECT TOP 10 [BusinessEntityID]
      ,[RateChangeDate]
      ,[Rate]
      ,[PayFrequency]
,[ModifiedDate]
FROM [AdventureWorks].[HumanResources].[EmployeePayHistory]
GO