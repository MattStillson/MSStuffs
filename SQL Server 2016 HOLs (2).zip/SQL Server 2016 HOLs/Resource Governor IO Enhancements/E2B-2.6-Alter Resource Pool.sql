USE [AdventureworksDW]
GO
ALTER RESOURCE POOL dbapool
WITH ( 
    MAX_IOPS_PER_VOLUME = 50 -- This is a very low IOPS, so should have a noticeable effect
);
GO
ALTER RESOURCE GOVERNOR RECONFIGURE;
