USE MASTER
GO
select g.name from sys.dm_exec_sessions s INNER JOIN sys.dm_resource_governor_workload_groups g
		ON s.group_id=g.group_id where s.session_id = @@SPID;
