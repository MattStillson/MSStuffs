-- NOTE: reporting service performance is not affected by resource governance
-- so we must show improvements here by a query
-- clear the buffers
CHECKPOINT
GO
DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE
GO

USE [AdventureworksDW]
GO

-- make a temporary table to do IO-intensive write operations on
CREATE TABLE Temp (ID int);
GO

-- do the IO-intensive write operation
INSERT INTO Temp
	select top 10000000 ProductKey from FactResellerSalesXL_CCI;
GO

-- clean up
DROP TABLE Temp