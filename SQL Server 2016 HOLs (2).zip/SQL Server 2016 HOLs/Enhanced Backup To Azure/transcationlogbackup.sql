--take 7 transaction log backups with FILE_SNAPSHOT, one per minute, and include the row count and the execution time in the backup file name 
DECLARE @count INT=1, @device NVARCHAR(120), @numrows INT;
WHILE @count <= 7
   BEGIN
	     SET @numrows = (SELECT COUNT (*) FROM Adventureworks.Production.Location);
	     SET @device = 'https://<mystorageaccountname>.blob.core.windows.net/<mystorageaccountcontainername>/tutorial-' + CONVERT (varchar(10),@numrows) + '-' + FORMAT(GETDATE(), 'yyyyMMddHHmmss') + '.bak';
	     BACKUP LOG Adventureworks TO URL = @device WITH FILE_SNAPSHOT;
	     SELECT * from sys.fn_db_backup_file_snapshots ('Adventureworks');
      WAITFOR DELAY '00:1:00'; 
	     SET @count = @count + 1;
   END;
