-- Verify that no file snapshot backups exist
SELECT * FROM sys.fn_db_backup_file_snapshots ('Adventureworks');
