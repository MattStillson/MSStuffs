-- Insert 30,000 new rows into the Production.Location table in the Adventureworks database in batches of 75
DECLARE @count INT=1, @inner INT;
WHILE @count < 400
   BEGIN
      BEGIN TRAN;
         SET @inner =1;
            WHILE @inner <= 75
               BEGIN;
                  INSERT INTO Adventureworks.Production.Location  
                     (Name, CostRate, Availability, ModifiedDate) 
                        VALUES (NEWID(), .5, 5.2, GETDATE());
                  SET @inner = @inner + 1;
               END;
      COMMIT;
   WAITFOR DELAY '00:00:01'; 
   SET @count = @count + 1;
   END;
SELECT COUNT (*) from Adventureworks.Production.Location;





[