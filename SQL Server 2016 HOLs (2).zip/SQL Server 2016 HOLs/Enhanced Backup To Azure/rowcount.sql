-- Verify row count at start
SELECT COUNT (*) from Adventureworks.Production.Location;
