USE master;
ALTER DATABASE AdventureWorks
SET RECOVERY FULL;
BACKUP DATABASE AdventureWorks
   TO URL = 'https://<<storagename>>.blob.core.windows.net/<<containername>>/AdventureWorks_onprem.bak' 
