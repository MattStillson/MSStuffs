Use msdb
go
EXEC managed_backup.sp_backup_config_schedule 
     @database_name =  'Adventureworks'
    ,@scheduling_option = 'Custom'
    ,@full_backup_freq_type = 'Weekly'
    ,@days_of_week = 'Monday'
    ,@backup_begin_time =  '17:30'
    ,@backup_duration = '02:00'
    ,@log_backup_freq = '00:05'
GO
