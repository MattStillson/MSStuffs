-- Backup the Adventureworks database with FILE_SNAPSHOT
BACKUP DATABASE Adventureworks
   TO URL = 'https://<<storagename>>.blob.core.windows.net/<<containername>>/Adventureworks_Azure.bak' 
   WITH FILE_SNAPSHOT;
