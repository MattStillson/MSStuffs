-- Restore AdventureWorks from URL to SQL Server instance using Azure blob storage for database files
RESTORE DATABASE Adventureworks
   FROM URL = 'https://<mystorageaccountname>.blob.core.windows.net/<mystorageaccountcontainername>/AdventureWorks_onprem.bak' 
   WITH
      MOVE 'AdventureWorks_Data' to 'https://<mystorageaccountname>.blob.core.windows.net/<mystorageaccountcontainername>/Adventureworks_Data.mdf'
     ,MOVE 'AdventureWorks_Log' to 'https://<mystorageaccountname>.blob.core.windows.net/<mystorageaccountcontainername>/Adventureworks_Log.ldf'
, REPLACE
