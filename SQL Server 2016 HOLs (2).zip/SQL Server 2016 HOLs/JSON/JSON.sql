Use AdventureWorks
Go

--Lab1 Converting Data into JSON Output
--1.1 Query the data in its relational format
SELECT H.SalesOrderNumber,H.OrderDate,D.UnitPrice,D.OrderQty
FROM Sales.SalesOrderHeader H
INNER JOIN Sales.SalesOrderDetail D ON H.SalesOrderID=D.SalesOrderID
Go

--1.2 Now return the output as JSON
SELECT Top 10 H.SalesOrderNumber,H.OrderDate,D.UnitPrice,D.OrderQty
FROM Sales.SalesOrderHeader H
INNER JOIN Sales.SalesOrderDetail D ON H.SalesOrderID=D.SalesOrderID
FOR JSON AUTO
Go

-- 1.3 Converting JSON Data to Rows and Columns with OPENJSON
DECLARE @json NVARCHAR(4000)
SET @json = '{"name":"John","surname":"Doe","age":45,"skills":["SQL","C#","MVC"]}';  

SELECT *  
FROM OPENJSON(@json)
        WITH (name nvarchar(30), surname nvarchar(30), age int, skills nvarchar(max) as json)
Go

--1.4 Explore JSON data structure by looking couple of records
SELECT H.SalesOrderNumber,H.OrderDate,D.UnitPrice,D.OrderQty
FROM Sales.SalesOrderHeader H
INNER JOIN Sales.SalesOrderDetail D ON H.SalesOrderID=D.SalesOrderID
WHERE H.SalesOrderID IN (43660,43669)
FOR JSON AUTO
Go

-- 1.5 Add a root key to JSON output
SELECT H.SalesOrderNumber,H.OrderDate,D.UnitPrice,D.OrderQty
FROM Sales.SalesOrderHeader H
INNER JOIN Sales.SalesOrderDetail D ON H.SalesOrderID=D.SalesOrderID
WHERE H.SalesOrderID IN (43660,43669)
FOR JSON AUTO, ROOT('SalesOrder')
Go


--Lab 2 Using FOR JSON PATH and other control structures
--2.1 start with a regular query for product information
SELECT TOP 7 M.ProductModelID, M.Name, ProductID, P.Name, ProductNumber, MakeFlag,
FinishedGoodsFlag, Color, Size, SafetyStockLevel, ReorderPoint, SellStartDate
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
Go


--2.2 Modify JSON structure with FOR JSON PATH
-- This would give error, since JSON will not allow the same attribute name more than once
SELECT TOP 7 M.ProductModelID, M.Name, ProductID, P.Name, ProductNumber, MakeFlag,
FinishedGoodsFlag, Color, Size, SafetyStockLevel, ReorderPoint, SellStartDate
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
FOR JSON PATH
Go


--2.3 Add alias names to avoid duplicay in names
SELECT TOP 7 M.ProductModelID, M.Name AS [ProductModel.Name], 
ProductID, P.Name AS [Product.Name], ProductNumber, MakeFlag,
FinishedGoodsFlag, Color, Size, SafetyStockLevel, ReorderPoint, SellStartDate
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
FOR JSON PATH
Go

--2.4 JSON result set where there are NULLs value for Size.  Notice that the Size attribute is not displayed
SELECT M.ProductModelID, M.Name AS [ProductModel.Name], 
ProductID, P.Name AS [Product.Name], Size
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
WHERE M.ProductModelID = 33
FOR JSON PATH
GO

--2.5 Add INCLUDE_NULL_VALUES to the FOR JSON PATH.  Note that the Size attribute is returned.
SELECT M.ProductModelID, M.Name AS [ProductModel.Name], 
ProductID, P.Name AS [Product.Name], Size
FROM Production.Product P
INNER JOIN Production.ProductModel M ON P.ProductModelID = M.ProductModelID
WHERE M.ProductModelID = 33
FOR JSON PATH, INCLUDE_NULL_VALUES
Go

--2.6 Alternate JSON structure with nested queries
SELECT M.ProductModelID, M.Name AS [ProductModel.Name], 
	(SELECT ProductID, P.Name AS [Product.Name], Size
	 FROM Production.Product P
	 WHERE P.ProductModelID = M.ProductModelID
	 FOR JSON PATH) AS P 
FROM Production.ProductModel M 
WHERE M.ProductModelID = 33
FOR JSON PATH
Go

-- 2.7 Using WITHOUT_ARRAY_WRAPPER
SELECT TOP 1 SalesOrderNumber, OrderDate, Status  
FROM Sales.SalesOrderHeader  
ORDER BY ModifiedDate  
FOR JSON PATH, WITHOUT_ARRAY_WRAPPER 
GO

-- 2.8 Without using WITHOUT_ARRAY_WRAPPER
 SELECT TOP 1 SalesOrderNumber, OrderDate, Status
FROM Sales.SalesOrderHeader  
ORDER BY ModifiedDate  
FOR JSON PATH
GO


-- Lab 3 Parsing with JSON
--3.1 Creating table with JSON data, using ISJSON for constraint check 
Use AdventureWorks
Go
CREATE TABLE [dbo].[JSON_DOC] (
 Id int IDENTITY PRIMARY KEY NONCLUSTERED,
 DocumentName nvarchar(100) NOT NULL, 
 AuthorName nvarchar(100) NOT NULL,
 InfoJson nvarchar(max) CONSTRAINT [Content_should_be_formatted_as_JSON] CHECK ( ISJSON( InfoJSON )> 0 )
) 

--3.2 Inserting a valid value
INSERT INTO [dbo].[JSON_DOC]
           ([DocumentName],[AuthorName],[InfoJson])
     VALUES
           ('Doc1','VALID','{"DocumentName":"Doc1","AuthorName":"Mark Doe","Pages":245,"Keywords":["SQL","C#","MVC"]}')
GO

-- 3.3 Inserting an invalid value
INSERT INTO [dbo].[JSON_DOC]
           ([DocumentName],[AuthorName],[InfoJson])
     VALUES
           ('Doc2','INVALID','Simple Text')
GO


-- Lab 4 Extracting values from JSON objects 
-- 4.1 Using JSON_VALUE for extraction
-- Create a sample JSON object
DECLARE @json NVARCHAR(4000)
SET @json = 
N'{
    "info":{  
      "type":1,
      "address":{  
        "town":"Bristol",
        "county":"Avon",
        "country":"England"
      },
      "tags":["Sport", "Water polo"]
   },
   "type":"Basic"
}'
-- Using JSON_VALUE function
SELECT
  JSON_VALUE(@json, '$.type') a,
  JSON_VALUE(@json, '$.info.type') b,
  JSON_VALUE(@json, '$.info.address.town') c,
  JSON_VALUE(@json, '$.info.tags[0]') d
GO

-- 4.2 Using JSON_QUERY for extraction
-- Create a sample JSON object
DECLARE @json NVARCHAR(4000)
SET @json = 
N'{
    "info":{  
      "type":1,
      "address":{  
        "town":"Bristol",
        "county":"Avon",
        "country":"England"
      },
      "tags":["Sport", "Water polo"]
   },
   "type":"Basic"
}'
-- Using JSON_QUERY function
SELECT
  JSON_QUERY(@json, '$') as [object],
  JSON_QUERY(@json, '$.info') as info,
  JSON_QUERY(@json, '$.info.address') as address,
  JSON_QUERY(@json, '$.info.tags') as tags
Go


 --4.3 Comparison betweek JSON_QUERY and JSON_VALUE
DECLARE @json NVARCHAR(4000)
SET @json = N'{ "a": "[1,2]", "b": [1,2], "c": "hi" } '
SELECT
  JSON_VALUE(@json, '$'),
  JSON_VALUE(@json, '$.a'),
  JSON_VALUE(@json, '$.b'),
  JSON_VALUE(@json, '$.b[0]'),
  JSON_VALUE(@json, '$.c')

SELECT
  JSON_QUERY(@json, '$'),
  JSON_QUERY(@json, '$.a'),
  JSON_QUERY(@json, '$.b'),
  JSON_QUERY(@json, '$.b[0]'),
  JSON_QUERY(@json, '$.c')
GO

--LAB5 Modify JSON 
--5.1 Modify a JSON Object
DECLARE @info NVARCHAR(100) = '{"name":"John","skills":["C#","SQL"]}'  
print @info  
-- Update skills as a text  
SET @info = JSON_MODIFY(@info, '$.skills', '["C#","T-SQL","Azure"]')  
print @info  
GO 



--5.2 Modify a JSON Column
--Create new table with JSON values
CREATE TABLE Sales.CustomerInfo( 
    Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Name NVARCHAR(50), Detail NVARCHAR(MAX))
GO
--Insert Dummy Data
INSERT INTO Sales.CustomerInfo ( Name, Detail )
VALUES
  ('John','{"Address":{"State":"CA","Country":"USA"}}'),
  ('Mark','{"Address":{"State":"FL","Country":"USA"}}');

--Select query on Dummy Data
SELECT * FROM Sales.CustomerInfo WHERE Name = 'Mark';

--Update the data using JSON_MODIFY
UPDATE  Sales.CustomerInfo  
SET Detail = JSON_MODIFY(Detail , '$.Address.State','CA')
WHERE Name = 'Mark';
--Query for the updated data
SELECT * FROM Sales.CustomerInfo WHERE Name = 'Mark';
--Drop the temporary table
DROP Table Sales.CustomerInfo;

--5.3 Apply multiple JSON_MODIFY commands 
DECLARE @info NVARCHAR(100) = '{"name":"John","skills":["C#","SQL"]}'  
print @info  
-- Multiple updates  
SET @info =   
    JSON_MODIFY(  
        JSON_MODIFY(  
            JSON_MODIFY(@info, '$.name', 'Mike')  
            , '$.surname', 'Smith')  
        , 'append $.skills', 'Azure')  
print @info  

SELECT SalesOrderNumber,OrderDate
FROM Sales.SalesOrderHeader
Go





