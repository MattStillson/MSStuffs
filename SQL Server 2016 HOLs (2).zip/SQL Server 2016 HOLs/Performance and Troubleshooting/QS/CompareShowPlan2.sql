 USE [AdventureWorks]
 GO
 SET STATISTICS IO ON
CREATE NONCLUSTERED INDEX [IX_Person_ModifiedDate_INCLUDES]
ON [Person].[Person] ([ModifiedDate])
INCLUDE ([BusinessEntityID],[FirstName],[LastName])
GO