SELECT name, object_id, type, type_desc, is_memory_optimized, durability, durability_desc
    FROM sys.tables
    WHERE is_memory_optimized=1

