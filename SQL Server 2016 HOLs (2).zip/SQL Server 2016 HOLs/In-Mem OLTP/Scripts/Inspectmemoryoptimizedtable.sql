SELECT name, user_type_id, is_memory_optimized
FROM sys.table_types
WHERE is_memory_optimized=1
