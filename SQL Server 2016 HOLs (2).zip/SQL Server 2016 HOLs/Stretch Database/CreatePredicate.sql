---------------------------------------------------------------------------------------------------
-- Create the predicate function on the database
---------------------------------------------------------------------------------------------------
CREATE FUNCTION Sales.fn_SalesOrderTracking_stretch_predicate(@eventDateTime datetime2)
RETURNS TABLE
WITH SCHEMABINDING 
AS 
RETURN SELECT 1 AS is_eligible
       WHERE @eventDateTime < CONVERT(datetime2, '1/1/2016', 101)
GO

