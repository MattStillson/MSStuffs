Use AdventureWorks
ALTER TABLE Sales.OrderTracking
SET
(REMOTE_DATA_ARCHIVE = ON
(
       MIGRATION_STATE = OUTBOUND,
       FILTER_PREDICATE = Sales.fn_SalesOrderTracking_stretch_predicate(EventDateTime)
))

SELECT * FROM sys.remote_data_archive_tables
